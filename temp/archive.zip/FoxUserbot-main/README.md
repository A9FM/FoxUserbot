# FoxUserbot
Simple userbot for Telegram.
