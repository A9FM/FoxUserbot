"""Please, ignore this file."""

settings = {'prefix': '!'}
version = '0.0.0.0'
module_list = {}
requirements_list = []
file_list = {}
